const fs = require('fs');

module.exports = {
    addPlayerPage: (req, res) => {
        res.render('add-employe.ejs', {
            title: "Кадровое агентсвто УСПЕХ"
            ,message: ''
        });
    },
    addPlayer: (req, res) => {
        let message = '';
        let first_name = req.body.first_name;
        let last_name = req.body.last_name;
        let position = req.body.position;
        let number = req.body.number;
        let username = req.body.username;

        let usernameQuery = "SELECT * FROM `employees` WHERE user_name = '" + username + "'";

        db.query(usernameQuery, (err, result) => {
            if (err) {
                return res.status(500).send(err);
            }
            if (result.length > 0) {
                message = 'Username already exists';
                res.render('add-employe.ejs', {
                    message,
                    title: "Кадровое агентсвто УСПЕХ"
                });
            } else {
                // send the employe's details to the database
                let query = "INSERT INTO `employees` (first_name, last_name, position, number, user_name) VALUES ('" + first_name + "', '" + last_name + "', '" + position + "', '" + number + "', '" +  username + "')";
                db.query(query, (err, result) => {
                    if (err) {
                        return res.status(500).send(err);
                    }
                    res.redirect('/');
                });
            }
        });
    },
    editPlayerPage: (req, res) => {
        let playerId = req.params.id;
        let query = "SELECT * FROM `employees` WHERE id = '" + playerId + "' ";
        db.query(query, (err, result) => {
            if (err) {
                return res.status(500).send(err);
            }
            res.render('edit-employe.ejs', {
                title: "Редактировать соискателя"
                ,employe: result[0]
                ,message: ''
            });
        });
    },
    editPlayer: (req, res) => {
        let playerId = req.params.id;
        let first_name = req.body.first_name;
        let last_name = req.body.last_name;
        let position = req.body.position;
        let number = req.body.number;

        let query = "UPDATE `employees` SET `first_name` = '" + first_name + "', `last_name` = '" + last_name + "', `position` = '" + position + "', `number` = '" + number + "' WHERE `employees`.`id` = '" + playerId + "'";
        db.query(query, (err, result) => {
            if (err) {
                return res.status(500).send(err);
            }
            res.redirect('/');
        });
    },
    deletePlayer: (req, res) => {
        let playerId = req.params.id;
        let deleteUserQuery = 'DELETE FROM employees WHERE id = "' + playerId + '"';
        db.query(deleteUserQuery, (err, result) => {
           if (err) {
               return res.status(500).send(err);
           }
           res.redirect('/');
        });
    }
};
