var ip = require("ip");

module.exports = {
    getHomePage: (req, res) => {
        let query = "SELECT * FROM `employees` ORDER BY id ASC"; // Запрос к БД, который показывает всех соискателей

        // execute query
        db.query(query, (err, result) => {
            if (err) {
                res.redirect('/');
            }
            res.render('index.ejs', {
                title: "Кадровое агентство \"Успех\"",
		message: ip.address(),
		employees: result
            });
        });
    },
};
