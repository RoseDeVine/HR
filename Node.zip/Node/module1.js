
var a = 1;
var b = 2;
var c = 3;
global.x = a;
global.y = b;
global.z = c;
