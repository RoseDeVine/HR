require('./module1');
function avg(x,y,z)
{
    return (x+y+z)/3;
}
console.log (avg(x,y,z));
