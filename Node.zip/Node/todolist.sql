/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 50525
 Source Host           : localhost:3306
 Source Schema         : todolist

 Target Server Type    : MySQL
 Target Server Version : 50525
 File Encoding         : 65001

 Date: 09/07/2019 16:49:05
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for projects
-- ----------------------------
DROP TABLE IF EXISTS `projects`;
CREATE TABLE `projects`  (
  `PRid` int(2) NOT NULL AUTO_INCREMENT,
  `PRname` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`PRid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of projects
-- ----------------------------
INSERT INTO `projects` VALUES (1, 'Work');
INSERT INTO `projects` VALUES (2, 'House');
INSERT INTO `projects` VALUES (3, 'Vilage');
INSERT INTO `projects` VALUES (4, 'Car');
INSERT INTO `projects` VALUES (5, 'noClass');

-- ----------------------------
-- Table structure for todoitems
-- ----------------------------
DROP TABLE IF EXISTS `todoitems`;
CREATE TABLE `todoitems`  (
  `TODOid` int(4) NOT NULL AUTO_INCREMENT,
  `TODOname` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `TODOendFINISH` date NULL DEFAULT NULL,
  `TODOstatus` int(1) NOT NULL,
  `PRid` int(3) NULL DEFAULT NULL,
  PRIMARY KEY (`TODOid`) USING BTREE,
  INDEX `PRid`(`PRid`) USING BTREE,
  CONSTRAINT `PRid` FOREIGN KEY (`PRid`) REFERENCES `projects` (`PRid`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 16 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of todoitems
-- ----------------------------
INSERT INTO `todoitems` VALUES (1, 'Rubbish', '2019-07-13', 0, 1);
INSERT INTO `todoitems` VALUES (2, 'PC', '2019-07-10', 1, 1);
INSERT INTO `todoitems` VALUES (3, 'Doc', '2019-07-19', 0, 1);
INSERT INTO `todoitems` VALUES (4, 'Cat', '2019-07-18', 0, 2);
INSERT INTO `todoitems` VALUES (5, 'Food', '2019-07-11', 1, 2);
INSERT INTO `todoitems` VALUES (6, 'Wash-up', '2019-07-09', 0, 2);
INSERT INTO `todoitems` VALUES (7, 'Flower', '0000-00-00', 0, 3);
INSERT INTO `todoitems` VALUES (8, 'Vegetables', '0000-00-00', 1, 3);
INSERT INTO `todoitems` VALUES (9, 'Pick-up', '2019-07-13', 0, 3);
INSERT INTO `todoitems` VALUES (10, 'TO', '2019-07-27', 1, 4);
INSERT INTO `todoitems` VALUES (11, 'GASOLINE', '2019-07-20', 0, 4);
INSERT INTO `todoitems` VALUES (12, 'ZARYADITSa', NULL, 1, 4);
INSERT INTO `todoitems` VALUES (13, 'buy-a-naushniki', '2019-07-09', 0, 5);
INSERT INTO `todoitems` VALUES (14, 'update-my-PC', NULL, 0, 5);
INSERT INTO `todoitems` VALUES (15, 'homeWork', NULL, 1, 5);

SET FOREIGN_KEY_CHECKS = 1;
